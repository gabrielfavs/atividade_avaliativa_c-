﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Digite um número inteiro positivo: ");
        int numero = int.Parse(Console.ReadLine());

        int fatorial = 1;
        while (numero > 1)
        {
            fatorial *= numero;
            numero--;
        }

        Console.WriteLine($"Fatorial = {fatorial}");
    }
}