﻿using System;

class Program
{
    static void Main()
    {
        Random rnd = new Random();
        int numeroSecreto = rnd.Next(1, 101);
        int tentativa, tentativas = 0;

        Console.WriteLine("Adivinhe o número entre 1 e 100:");

        do
        {
            tentativa = int.Parse(Console.ReadLine());
            tentativas++;

            if (tentativa < numeroSecreto)
                Console.WriteLine("Mais alto!");
            else if (tentativa > numeroSecreto)
                Console.WriteLine("Mais baixo!");

        } while (tentativa != numeroSecreto);

        Console.WriteLine($"Parabéns! Você acertou em {tentativas} tentativas.");
    }
}