﻿using System;

class Produto
{
    public string Nome;
    public double Preco;
    public int Quantidade;

    public Produto(string nome, double preco, int quantidade)
    {
        Nome = nome;
        Preco = preco;
        Quantidade = quantidade;
    }

    public double ValorTotal() => Preco * Quantidade;
}

class Program
{
    static void Main()
    {
        Produto[] produtos = new Produto[3];

        for (int i = 0; i < 3; i++)
        {
            Console.Write($"Nome do produto {i + 1}: ");
            string nome = Console.ReadLine();

            Console.Write("Preço: ");
            double preco = double.Parse(Console.ReadLine());

            Console.Write("Quantidade: ");
            int quantidade = int.Parse(Console.ReadLine());

            produtos[i] = new Produto(nome, preco, quantidade);
        }

        Console.WriteLine("\nProdutos cadastrados:");
        foreach (var p in produtos)
        {
            Console.WriteLine($"{p.Nome} - Total em estoque: {p.ValorTotal()}");
        }
    }
}