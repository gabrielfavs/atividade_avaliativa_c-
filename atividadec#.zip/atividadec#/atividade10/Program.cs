﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        List<string> tarefas = new List<string>();
        string entrada;

        do
        {
            Console.Write("Digite uma tarefa (ou 'fim' para sair): ");
            entrada = Console.ReadLine();

            if (entrada.ToLower() != "fim")
                tarefas.Add(entrada);

        } while (entrada.ToLower() != "fim");

        Console.WriteLine("\nTarefas cadastradas:");
        for (int i = 0; i < tarefas.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {tarefas[i]}");
        }
    }
}