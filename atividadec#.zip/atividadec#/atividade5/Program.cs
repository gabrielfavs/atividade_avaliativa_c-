﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Digite uma palavra ou frase: ");
        string texto = Console.ReadLine().ToLower().Replace(" ", "");

        string invertido = "";
        for (int i = texto.Length - 1; i >= 0; i--)
            invertido += texto[i];

        Console.WriteLine(texto == invertido ? "É um palíndromo." : "Não é um palíndromo.");
    }
}