﻿using System;

class Program
{
    static void Main()
    {
        int opcao;
        do
        {
            Console.WriteLine("\n1 - Celsius para Fahrenheit");
            Console.WriteLine("2 - Fahrenheit para Celsius");
            Console.WriteLine("3 - Sair");
            Console.Write("Escolha: ");
            opcao = int.Parse(Console.ReadLine());

            switch (opcao)
            {
                case 1:
                    Console.Write("Temperatura em Celsius: ");
                    double c = double.Parse(Console.ReadLine());
                    Console.WriteLine($"{c}C = {(c * 9 / 5) + 32}F");
                    break;
                case 2:
                    Console.Write("Temperatura em Fahrenheit: ");
                    double f = double.Parse(Console.ReadLine());
                    Console.WriteLine($"{f}F = {(f - 32) * 5 / 9}C");
                    break;
                case 3:
                    Console.WriteLine("Saindo...");
                    break;
                default:
                    Console.WriteLine("Opção inválida.");
                    break;
            }

        } while (opcao != 3);
    }
}