﻿using System;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        Console.Write("Digite uma senha: ");
        string senha = Console.ReadLine();

        bool tamanhoValido = senha.Length >= 8;
        bool temMaiuscula = Regex.IsMatch(senha, "[A-Z]");
        bool temNumero = Regex.IsMatch(senha, "[0-9]");
        bool temEspecial = Regex.IsMatch(senha, @"[!@#$%^&*(),.?""{}|<>]");

        if (tamanhoValido && temMaiuscula && temNumero && temEspecial)
        {
            Console.WriteLine("Senha forte!");
        }
        else
        {
            Console.WriteLine("Senha fraca. Certifique-se de incluir:\n- Pelo menos 8 caracteres\n- Uma letra maiúscula\n- Um número\n- Um caractere especial.");
        }
    }
}
